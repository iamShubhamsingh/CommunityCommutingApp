import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { RideSeeker } from '../Models/rideseeker.model';

@Injectable({
  providedIn: 'root'
})
export class RideseekerdataService {

  baseApiUrl: string = environment.baseApiUrl;

  constructor(private http: HttpClient) { }

  getAllRideSeeker(): Observable<RideSeeker[]>
  {
      return this.http.get<RideSeeker[]>(this.baseApiUrl + '/api/RideSeeker');
  }

  addRideSeeker(RegisterRideSeekerRequest: RideSeeker): Observable<RideSeeker> {
    RegisterRideSeekerRequest.rsId = '000000';
    return this.http.post<RideSeeker>(this.baseApiUrl + '/api/RideSeeker/new', RegisterRideSeekerRequest);
  }

  deleteRideSeeker(rsId:string) : Observable<any> {
    return this.http.delete<any>(this.baseApiUrl + `/api/RideSeeker/${rsId}`);
  }

}
