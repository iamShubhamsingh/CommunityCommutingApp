import { TestBed } from '@angular/core/testing';

import { RideseekerdataService } from './rideseekerdata.service';

describe('RideseekerdataService', () => {
  let service: RideseekerdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RideseekerdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
