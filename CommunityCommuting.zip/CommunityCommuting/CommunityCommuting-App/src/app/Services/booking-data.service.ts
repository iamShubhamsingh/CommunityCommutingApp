import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Booking } from '../Models/booking.model';

@Injectable({
  providedIn: 'root'
})
export class BookingDataService {
  
  bookingDateTime: string = '';
  baseApiUrl: string = environment.baseApiUrl;

  constructor(private http: HttpClient) {
  } 
    
  getAllBookings(): Observable<Booking[]>
  {
    return this.http.get<Booking[]>(this.baseApiUrl + '/api/RideSeeker/getBookings');
  }

  addBooking(addBookingRequest: Booking): Observable<Booking> {
    //addBookingRequest.bookingDate = this.bookingDateTime;
    return this.http.post<Booking>(this.baseApiUrl + '/api/RideSeeker/bookRide', addBookingRequest);
  }

  deleteBooking(bookingId:number) : Observable<any> {
    return this.http.delete<any>(this.baseApiUrl + `/api/RideSeeker/${bookingId}/update`);
  }
  
}
