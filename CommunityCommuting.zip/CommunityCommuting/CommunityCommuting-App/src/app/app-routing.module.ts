import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterRideSeekerComponent } from './Components/RideSeeker/register-ride-seeker/register-ride-seeker.component';
import { RideSeekerListComponent } from './Components/RideSeeker/ride-seeker-list/ride-seeker-list.component';
//import { EditRideseekerComponent } from './Components/RideSeeker/edit-rideseeker/edit-rideseeker.component';
import { HomePageComponent } from './Components/home-page/home-page.component';
import { BookingListComponent } from './Components/Booking/booking-list/booking-list.component';
import { AddBookingComponent } from './Components/Booking/add-booking/add-booking.component';

const routes: Routes = [
  {
    path: '',
  component: HomePageComponent 
  },
  {
    path: 'userlist',
    component: RideSeekerListComponent
  },
  {
    path: 'registration',
    component: RegisterRideSeekerComponent
  },
  {
    path: 'bookride',
    component: BookingListComponent
  },
  {
    path: 'bookride/add',
    component: AddBookingComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
