export interface Booking {
    bookingId: number,
    rsId: string,
    status: string,
    bookingDate: string,
}