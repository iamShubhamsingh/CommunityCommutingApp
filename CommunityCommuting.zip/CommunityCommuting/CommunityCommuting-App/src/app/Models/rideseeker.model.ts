export interface RideSeeker {
    rsId: string;
    firstName: string;
    lastName: string;
    adharcard: number;
    emailId: string;
    phone: number;
    address: string;
    status: string;
    birthday: string;
}