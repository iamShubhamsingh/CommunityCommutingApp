import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterRideSeekerComponent } from './Components/RideSeeker/register-ride-seeker/register-ride-seeker.component';
import { RideSeekerListComponent } from './Components/RideSeeker/ride-seeker-list/ride-seeker-list.component';
//import { EditRideseekerComponent } from './Components/RideSeeker/edit-rideseeker/edit-rideseeker.component';
import { NavBarComponent } from './Components/nav-bar/nav-bar.component';
import { HomePageComponent } from './Components/home-page/home-page.component';
import { BookingListComponent } from './Components/Booking/booking-list/booking-list.component';
import { AddBookingComponent } from './Components/Booking/add-booking/add-booking.component';
import { FooterComponent } from './Components/footer/footer.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterRideSeekerComponent,
    RideSeekerListComponent,
    //EditRideseekerComponent,
    NavBarComponent,
    HomePageComponent,
    BookingListComponent,
    AddBookingComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [
   // provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
