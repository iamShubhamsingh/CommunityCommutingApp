import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Booking } from '../../../Models/booking.model';
import { BookingDataService } from '../../../Services/booking-data.service';

@Component({
  selector: 'app-add-booking',
  templateUrl: './add-booking.component.html',
  styleUrl: './add-booking.component.css'
})
export class AddBookingComponent implements OnInit {

  addBookingRequest: Booking = {
    bookingId: 0,
    rsId: '',
    status: '',
    bookingDate: '',
  };

  constructor(private bookingDataService: BookingDataService, private router: Router) {}

  ngOnInit(): void {
    
  }

  addBooking() {
    console.log(this.addBookingRequest);
    this.bookingDataService.addBooking(this.addBookingRequest).subscribe({
      next: (booking) => {
        console.log(booking);
        this.router.navigate(['bookride']);
      }
    });
  }
}
