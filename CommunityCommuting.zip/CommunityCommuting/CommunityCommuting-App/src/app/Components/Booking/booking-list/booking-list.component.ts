import { Component, OnInit } from '@angular/core';
import { Booking } from '../../../Models/booking.model';
import { BookingDataService } from '../../../Services/booking-data.service';

@Component({
  selector: 'app-booking-list',
  templateUrl: './booking-list.component.html',
  styleUrl: './booking-list.component.css'
})
export class BookingListComponent implements OnInit {

  booking: Booking[] = [];

  constructor(private bookingService: BookingDataService ) {}

  ngOnInit(): void {

    this.fetchBookings();
    
  }

  deleteRide(bookingId:number): void {
    if(bookingId){
      this.bookingService.deleteBooking(bookingId).subscribe({
        next: (response) => {
          alert('Booking deleted successfully.');
          this.fetchBookings();
        },
        error: (error) => {
          console.log(error);
        }
      });
    }
  }

  fetchBookings() {
    this.bookingService.getAllBookings().subscribe({
      next: (booking) => {
        this.booking = booking;
      },
      error: (response) => {
        console.log(response);
      }
    })
  }
}
