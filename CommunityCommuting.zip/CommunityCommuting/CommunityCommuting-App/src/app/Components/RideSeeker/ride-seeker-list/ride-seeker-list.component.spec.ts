import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RideSeekerListComponent } from './ride-seeker-list.component';

describe('RideSeekerListComponent', () => {
  let component: RideSeekerListComponent;
  let fixture: ComponentFixture<RideSeekerListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RideSeekerListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RideSeekerListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
