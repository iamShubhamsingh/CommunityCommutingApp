import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RideSeeker } from '../../../Models/rideseeker.model';
import { RideseekerdataService } from '../../../Services/rideseekerdata.service';

@Component({
  selector: 'app-ride-seeker-list',
  templateUrl: './ride-seeker-list.component.html',
  styleUrl: './ride-seeker-list.component.css'
})
export class RideSeekerListComponent {

  rideSeeker: RideSeeker[] = [];
  

  constructor(private rideseekerdataService: RideseekerdataService, private router: Router) {}

  ngOnInit(): void {
    this.fetchRideSeekers();
  }

  onDelete(rsId:string): void {
    if(rsId){
      this.rideseekerdataService.deleteRideSeeker(rsId).subscribe({
        next: (response) => {
          alert('Rideseeker deleted successfully.');
          this.fetchRideSeekers();
        }
      });
    }
  }

  fetchRideSeekers(){
    this.rideseekerdataService.getAllRideSeeker().subscribe({
      next: (rideSeeker) => {
        this.rideSeeker = rideSeeker;
      },
      error: (response) => {
        console.log(response);
      }
    })
  }


}
