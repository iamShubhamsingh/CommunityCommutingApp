import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterRideSeekerComponent } from './register-ride-seeker.component';

describe('RegisterRideSeekerComponent', () => {
  let component: RegisterRideSeekerComponent;
  let fixture: ComponentFixture<RegisterRideSeekerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RegisterRideSeekerComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(RegisterRideSeekerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
