import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { RideSeeker } from '../../../Models/rideseeker.model';
import { RideseekerdataService } from '../../../Services/rideseekerdata.service';

@Component({
  selector: 'app-register-ride-seeker',
  templateUrl: './register-ride-seeker.component.html',
  styleUrl: './register-ride-seeker.component.css'
})
export class RegisterRideSeekerComponent {

  RegisterRideSeekerRequest: RideSeeker = {
    rsId: '',
    firstName: '',
    lastName: '',
    adharcard: 0,
    emailId: '',
    phone: 0,
    address: '',
    status: '',
    birthday: ''
  };

  constructor(private rideseekerdataService: RideseekerdataService, private router: Router) {}

  ngOnInit(): void {}

  addRideSeeker() {
    this.rideseekerdataService.addRideSeeker(this.RegisterRideSeekerRequest).subscribe({
      next: (rideSeeker) => {
        this.router.navigate(['userlist']);
      }
    });
  }

}
