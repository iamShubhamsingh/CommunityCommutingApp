using System;
using System.ComponentModel.DataAnnotations;
using CommunityCommuting_RideSeeker.BAL.DTOs;
using CommunityCommuting_RideSeeker.BAL.Service.Classes;
using CommunityCommuting_RideSeeker.BAL.Service.Interface;
using CommunityCommuting_RideSeeker.DAL.Repositories.Interface;
using CommunityCommuting_RideSeeker.Models;
using Moq;
using NUnit.Framework;

namespace RideSeekerTest
{
    [TestFixture]
    public class RideSeekerServiceTests
    {
        private Mock<IRideSeeker> _rideSeekerRepoMock;
        private IRideSeekerDTO _rideSeekerService;

        [SetUp]
        public void SetUp()
        {
            _rideSeekerRepoMock = new Mock<IRideSeeker>();
            _rideSeekerService = new RideSeekerService(_rideSeekerRepoMock.Object);
        }

        [Test]
        public void RegisterRideSeeker_ValidData_CallsRegisterRideSeeker()
        {
            // Arrange
            var rideSeekerDTO = new RideSeekerDTO
            {
                // Set up valid data for testing
                RsId = null,
                Adharcard = 123456789012,
                EmailId = "test@cognizant.com",
                Phone = 1234567890,
                FirstName = "Shubham",
                LastName = "Singh",
                Address = "Korba",
                Status = "Registered",
            };

            // Act
            _rideSeekerService.RegisterRideSeeker(rideSeekerDTO);

            // Assert
            _rideSeekerRepoMock.Verify(repo => repo.RegisterRideSeeker(It.IsAny<RideSeeker>()), Times.Once);
        }

        [Test]
        public void RegisterRideSeeker_InvalidPhone_ThrowsArgumentException()
        {
            // Arrange
            var rideSeekerDTO = new RideSeekerDTO
            {
                // Set up invalid phone number
                Phone = 12345,
            };

            // Act & Assert
            Assert.Throws<ArgumentException>(() => _rideSeekerService.RegisterRideSeeker(rideSeekerDTO));
        }

        [Test]
        public void RegisterRideSeeker_InvalidEmail_ThrowsArgumentException()
        {
            var rideSeekerDTO = new RideSeekerDTO
            {
                EmailId = "test@example.com", // Invalid Data
            };

            Assert.Throws<ArgumentException>(() => _rideSeekerService.RegisterRideSeeker(rideSeekerDTO));
        }

        [Test]
        public void RegisterRideSeeker_InvalidAdharcard_ThrowsArgumentException()
        {
            var rideSeekerDTO = new RideSeekerDTO
            {
                Adharcard = 123456, // Invalid Data
            };

            Assert.Throws<ArgumentException>(() => _rideSeekerService.RegisterRideSeeker(rideSeekerDTO));
        }

        [Test]
        public void RegisterRideSeeker_InvalidStatus_ThrowsArgumentException()
        {
            var rideSeekerDTO = new RideSeekerDTO
            {
                Status = "Example", // Invalid Data
            };

            Assert.Throws<ArgumentException>(() => _rideSeekerService.RegisterRideSeeker(rideSeekerDTO));
        }

        [Test]
        public void UnregisterRideSeeker_ValidRsId_CallsUnregisterRideSeeker()
        {
            // Arrange
            var rsId = "REAB22"; // Example RsId

            // Act
            _rideSeekerService.UnregisterRideSeeker(rsId);

            // Assert
            _rideSeekerRepoMock.Verify(repo => repo.UnregisterRideSeeker(rsId), Times.Once);
        }

        [Test]
        public void UnregisterRideSeeker_InvalidRsId_DoesNotCallUnregisterRideSeeker()
        {
            // Arrange
            var rsId = "SESI99"; // Example invalid RsId

            // Act
            _rideSeekerService.UnregisterRideSeeker(rsId);

            // Assert
            _rideSeekerRepoMock.Verify(repo => repo.UnregisterRideSeeker(rsId), Times.Once);
        }
    }
}