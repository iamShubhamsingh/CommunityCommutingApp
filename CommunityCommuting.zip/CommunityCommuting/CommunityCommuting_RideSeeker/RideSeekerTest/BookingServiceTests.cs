﻿using CommunityCommuting_RideSeeker.BAL.DTOs;
using CommunityCommuting_RideSeeker.BAL.Service.Classes;
using CommunityCommuting_RideSeeker.DAL.Repositories.Interface;
using Moq;
using CommunityCommuting_RideSeeker.Models;


namespace RideSeekerTest
{
    [TestFixture]
    public class BookingServiceTests
    {
        private BookingService _bookingService;
        private Mock<IBooking> _bookingRepoMock;

        [SetUp]
        public void SetUp()
        {
            // Create a mock for the IBooking repository
            _bookingRepoMock = new Mock<IBooking>();

            // Initialize the BookingService with the mock repository
            _bookingService = new BookingService(_bookingRepoMock.Object);
        }

        [Test]
        public void BookRide_ValidBookingData_CallsBookRideMethod()
        {
            // Arrange
            var bookingDTO = new BookingDTO
            {
                BookingId = 1,
                RsId = "RESI99",
                Status = "Confirmed",
                BookingDate = DateTime.Now.AddDays(1)
            };

            // Act
            _bookingService.BookRide(bookingDTO);

            // Assert
            _bookingRepoMock.Verify(repo => repo.BookRide(It.IsAny<Booking>()), Times.Once);
        }

        [Test]
        public void BookRide_InvalidBookingStatus_ThrowsArgumentException()
        {
            // Arrange
            var bookingDTO = new BookingDTO
            {
                BookingId = 2,
                RsId = "123",
                Status = "", // Invalid status
                BookingDate = DateTime.Now.AddDays(2)
            };

            // Act & Assert
            Assert.Throws<ArgumentException>(() => _bookingService.BookRide(bookingDTO));
        }

        [Test]
        public void BookRide_PastBookingDate_ThrowsArgumentException()
        {
            // Arrange
            var bookingDTO = new BookingDTO
            {
                BookingId = 3,
                RsId = "RESI99",
                Status = "Confirmed",
                BookingDate = DateTime.Now.AddDays(-1) // Past date
            };

            // Act & Assert
            Assert.Throws<ArgumentException>(() => _bookingService.BookRide(bookingDTO));
        }

        [Test]
        public void CancelRide_ValidBookingId_CallsCancelRideMethod()
        {
            // Arrange
            var bookingId = 123;

            // Act
            _bookingService.CancelRide(bookingId);

            // Assert
            _bookingRepoMock.Verify(repo => repo.CancelRide(bookingId), Times.Once);
        }
    }
}
