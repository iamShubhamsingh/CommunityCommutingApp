using CommunityCommuting_RideSeeker.BAL.Service.Classes;
using CommunityCommuting_RideSeeker.BAL.Service.Interface;
using CommunityCommuting_RideSeeker.DAL.Repositories.Classes;
using CommunityCommuting_RideSeeker.DAL.Repositories.Interface;
using CommunityCommuting_RideSeeker.Models;
using log4net.Config;
using log4net;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddDbContext<CCA_RSDBContext>(item => item.UseSqlServer(builder.Configuration.GetConnectionString("RideSeekerConn")));
builder.Services.AddScoped<IRideSeeker, RideSeekerRepo>();
builder.Services.AddScoped<IBooking, BookingRepo>();
builder.Services.AddScoped<IRideSeekerDTO, RideSeekerService>();
builder.Services.AddScoped<IBookingDTO, BookingService>();
builder.Services.AddControllers();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

XmlConfigurator.Configure(new FileInfo("log4net.config"));
builder.Services.AddSingleton(LogManager.GetLogger(typeof(Program)));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseCors(policy => policy.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin());

app.UseAuthorization();

app.MapControllers();

app.Run();
