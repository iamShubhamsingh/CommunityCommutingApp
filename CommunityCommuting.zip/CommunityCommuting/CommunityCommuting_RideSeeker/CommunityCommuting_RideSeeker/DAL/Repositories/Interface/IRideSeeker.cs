﻿using CommunityCommuting_RideSeeker.Models;

namespace CommunityCommuting_RideSeeker.DAL.Repositories.Interface
{
    public interface IRideSeeker
    {
        void RegisterRideSeeker(RideSeeker rideSeeker);
        void UnregisterRideSeeker(string rsId);
    }
}
