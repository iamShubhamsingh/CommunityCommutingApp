﻿using CommunityCommuting_RideSeeker.Models;

namespace CommunityCommuting_RideSeeker.DAL.Repositories.Interface
{
    public interface IBooking
    {
        void BookRide(Booking booking);
        void CancelRide(int bookingId);
    }
}
