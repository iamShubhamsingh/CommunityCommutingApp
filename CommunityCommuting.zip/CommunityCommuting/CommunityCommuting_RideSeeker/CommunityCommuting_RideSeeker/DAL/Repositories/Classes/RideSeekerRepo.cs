﻿using CommunityCommuting_RideSeeker.DAL.Repositories.Interface;
using CommunityCommuting_RideSeeker.Models;

namespace CommunityCommuting_RideSeeker.DAL.Repositories.Classes
{
    public class RideSeekerRepo : IRideSeeker
    {
        private readonly CCA_RSDBContext _context;
        public RideSeekerRepo(CCA_RSDBContext context)
        {
            _context = context;
        }

        public void RegisterRideSeeker(RideSeeker rideSeeker)
        {
            _context.RideSeekers.Add(rideSeeker);
            _context.SaveChanges();
        }

        public void UnregisterRideSeeker(string rsId)
        {
            var rideSeeker = _context.RideSeekers.FirstOrDefault(rs => rs.RsId == rsId);
            if (rideSeeker != null)
            {
                _context.RideSeekers.Remove(rideSeeker);
                _context.SaveChanges();
            }
        }
    }
}
