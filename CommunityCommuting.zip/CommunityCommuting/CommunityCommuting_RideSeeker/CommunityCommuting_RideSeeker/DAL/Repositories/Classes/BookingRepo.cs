﻿using CommunityCommuting_RideSeeker.DAL.Repositories.Interface;
using CommunityCommuting_RideSeeker.Models;
using Microsoft.EntityFrameworkCore;

namespace CommunityCommuting_RideSeeker.DAL.Repositories.Classes
{
    public class BookingRepo : IBooking
    {
        private readonly CCA_RSDBContext _context;

        public BookingRepo(CCA_RSDBContext context)
        {
            _context = context;
        }

        public void BookRide(Booking booking)
        {
            _context.Bookings.Add(booking);
            _context.SaveChanges();
        }

        public void CancelRide(int bookingId)
        {
            var booking = _context.Bookings.FirstOrDefault(b => b.BookingId == bookingId);
            if (booking != null)
            {
                _context.Bookings.Remove(booking);
                _context.SaveChanges();
            }
        }
    }
}
