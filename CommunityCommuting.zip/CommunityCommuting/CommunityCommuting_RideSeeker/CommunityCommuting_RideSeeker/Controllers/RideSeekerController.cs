﻿using CommunityCommuting_RideSeeker.BAL.DTOs;
using CommunityCommuting_RideSeeker.BAL.Service.Classes;
using CommunityCommuting_RideSeeker.BAL.Service.Interface;
using CommunityCommuting_RideSeeker.DAL.Repositories.Classes;
using CommunityCommuting_RideSeeker.DAL.Repositories.Interface;
using CommunityCommuting_RideSeeker.Models;
using log4net;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CommunityCommuting_RideSeeker.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RideSeekerController : ControllerBase
    {
        private readonly IRideSeekerDTO rideSeekerService;
        private readonly IBookingDTO bookingService;
        private readonly CCA_RSDBContext cCA_RSDBContext;
        private readonly ILog logger;

        public RideSeekerController(IRideSeekerDTO rideSeekerService, IBookingDTO bookingService, CCA_RSDBContext cCA_RSDBContext,ILog logger)
        {
            this.rideSeekerService = rideSeekerService;
            this.bookingService = bookingService;
            this.cCA_RSDBContext = cCA_RSDBContext;
            this.logger = logger;
        }

        //Endpoints for Ride Seeker Rigistration
        [HttpPost("new")]
        public IActionResult RegisterRideSeeker(RideSeekerDTO rideSeeker)
        {
            try
            {
                rideSeekerService.RegisterRideSeeker(rideSeeker);
                return Ok(new { message="Successfully Registered!!!" });
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return Problem(title: "An error occured while registering the ride seeker: ",detail: ex.Message, statusCode: 400);
            }
        }

        //Endpoints for Ride Seeker Un-Registration
        [HttpDelete("{id}")]
        public IActionResult UnregisterRideSeeker(string id)
        {
            try
            {
                rideSeekerService.UnregisterRideSeeker(id);
                return Ok();
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return Problem(title: "An error occured while Un-registering the ride seeker: ", detail: ex.Message, statusCode: 400);
            }
        }

        //Endpoints for Booking a Ride for Ride Seeker
        [HttpPost("bookRide")]
        public IActionResult Book(BookingDTO booking)
        {
            try
            {
                bookingService.BookRide(booking);
                return Ok(new { message = "Successfully Booked a Ride!!!" });
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return Problem(title: "An error occured while Booking the Ride for Ride Seeker: ", detail: ex.Message, statusCode: 400);
            }
        }

        //Endpoints for Cancel a Boojing for Ride Seeker
        [HttpDelete("{id}/update")]
        public IActionResult Cancel (int id)
        {
            try
            {
                bookingService.CancelRide(id);
                return Ok(new { message = "Successfully Cancelled a Ride!!!" });
            }
            catch (Exception ex)
            {
                logger.Error(ex.Message);
                return Problem(title: "An error occured while Cancelling the Ride for Ride Seeker: ", detail: ex.Message, statusCode: 400);
            }
        }

        //Endpoints for viewing all the Registered Ride Seeker
        [HttpGet]
        public async Task<IActionResult> GetAllRideSeeker()
        {
            var rideseekers = await cCA_RSDBContext.RideSeekers.ToListAsync();
            return Ok(rideseekers);
        }

        //Endpoints for viewing all the Registered Ride Seeker
        [HttpGet("getBookings")]
        public async Task<IActionResult> GetAllBookings()
        {
            var booking = await cCA_RSDBContext.Bookings.ToListAsync();
            return Ok(booking);
        }

    }
}
