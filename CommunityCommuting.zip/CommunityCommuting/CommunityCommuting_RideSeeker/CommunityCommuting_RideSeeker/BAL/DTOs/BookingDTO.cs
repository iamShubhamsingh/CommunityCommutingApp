﻿namespace CommunityCommuting_RideSeeker.BAL.DTOs
{
    public class BookingDTO
    {
        public int BookingId { get; set; }
        public string RsId { get; set; } = null!;
        public string? Status { get; set; }
        public DateTime? BookingDate { get; set; }
    }
}
