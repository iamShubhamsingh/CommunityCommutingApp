﻿using CommunityCommuting_RideSeeker.BAL.DTOs;
using CommunityCommuting_RideSeeker.BAL.Service.Interface;
using CommunityCommuting_RideSeeker.DAL.Repositories.Classes;
using CommunityCommuting_RideSeeker.DAL.Repositories.Interface;
using CommunityCommuting_RideSeeker.Models;
using System;

namespace CommunityCommuting_RideSeeker.BAL.Service.Classes
{
    public class RideSeekerService : IRideSeekerDTO
    {
        public readonly IRideSeeker _rideSeekerRepo;
        public RideSeekerService(IRideSeeker rideSeekerRepo)
        {
            _rideSeekerRepo = rideSeekerRepo;
        }

        public void RegisterRideSeeker(RideSeekerDTO rideSeekerDTO)
        {
            ValidateRideSeekerData(rideSeekerDTO);

            rideSeekerDTO.RsId = GenerateRideSeekerId(rideSeekerDTO);

            var rideSeeker = new RideSeeker
            {
                RsId = rideSeekerDTO.RsId,
                Adharcard = rideSeekerDTO.Adharcard,
                EmailId = rideSeekerDTO.EmailId,
                Phone = rideSeekerDTO.Phone,
                FirstName = rideSeekerDTO.FirstName,
                LastName = rideSeekerDTO.LastName,
                Address = rideSeekerDTO.Address,
                Status = rideSeekerDTO.Status,
                Birthday = rideSeekerDTO.Birthday,
            };
            _rideSeekerRepo.RegisterRideSeeker(rideSeeker);
        }

        private string GenerateRideSeekerId(RideSeekerDTO rideSeekerDTO)
        {
            string lastNameFirstTwoLetters = rideSeekerDTO.LastName.Substring(0, 2);
            string yearLastTwoDigits = rideSeekerDTO.Birthday?.Year.ToString().Substring(2) ?? "00";
            return "RE" + lastNameFirstTwoLetters + yearLastTwoDigits;
        }

        private void ValidateRideSeekerData(RideSeekerDTO rideSeekerDTO)
        {
            if(rideSeekerDTO.Phone?.ToString().Length != 10)
            {
                throw new ArgumentException("Phone number should be exactly 10 digits long.");
            }

            if(!rideSeekerDTO.EmailId?.EndsWith("@cognizant.com")??false)
            {
                throw new ArgumentException("Email address should always end with '@cognizant.com'.");
            }

            if(string.IsNullOrEmpty(rideSeekerDTO.FirstName) || string.IsNullOrEmpty(rideSeekerDTO.LastName) || rideSeekerDTO.FirstName.Length < 3 || rideSeekerDTO.LastName.Length < 3)
            {
                throw new ArgumentException("First and Last name must be minimum 3 characters long.");
            }

            if(rideSeekerDTO.Adharcard?.ToString().Length != 12) 
            {
                throw new ArgumentException("Aadhar number should be 12 digits long.");
            }

            if(rideSeekerDTO.Status!="Registered" && rideSeekerDTO.Status != "Unregistered")
            {
                throw new ArgumentException("Allowed values for RideSeeker status are 'Registered' and 'Unregistered'.");
            }
        }

        public void UnregisterRideSeeker(string rsId)
        {
            _rideSeekerRepo.UnregisterRideSeeker(rsId);
        }
    }
}
