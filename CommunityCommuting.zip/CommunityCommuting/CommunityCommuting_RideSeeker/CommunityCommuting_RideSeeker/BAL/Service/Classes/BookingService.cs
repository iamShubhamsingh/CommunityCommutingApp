﻿using CommunityCommuting_RideSeeker.BAL.DTOs;
using CommunityCommuting_RideSeeker.BAL.Service.Interface;
using CommunityCommuting_RideSeeker.DAL.Repositories.Classes;
using CommunityCommuting_RideSeeker.DAL.Repositories.Interface;
using CommunityCommuting_RideSeeker.Models;
using System;

namespace CommunityCommuting_RideSeeker.BAL.Service.Classes
{
    public class BookingService : IBookingDTO
    {
        private readonly IBooking _bookingRepo;
        public BookingService(IBooking bookingRepo)
        {
            _bookingRepo = bookingRepo;
        }

        public void BookRide(BookingDTO bookingDTO)
        {
            ValidateBookingData(bookingDTO);
            var booking = new Booking
            {
                BookingId = bookingDTO.BookingId,
                RsId = bookingDTO.RsId,
                Status = bookingDTO.Status,
                BookingDate = bookingDTO.BookingDate,
            };
            _bookingRepo.BookRide(booking);
        }

        private void ValidateBookingData(BookingDTO bookingDTO)
        {
            if (string.IsNullOrEmpty(bookingDTO.Status))
            {
                throw new ArgumentException("Booking status is required.");
            }

            if (bookingDTO.BookingDate.HasValue && bookingDTO.BookingDate.Value < DateTime.Today)
            {
                throw new ArgumentException("Booking Date cannot be in the past.");
            }
        }

        public void CancelRide(int bookingId)
        {
            _bookingRepo.CancelRide(bookingId);
        }
    }
}
