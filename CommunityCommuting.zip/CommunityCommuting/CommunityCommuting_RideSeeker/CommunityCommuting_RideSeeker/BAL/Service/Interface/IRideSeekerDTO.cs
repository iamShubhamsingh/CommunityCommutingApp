﻿using CommunityCommuting_RideSeeker.BAL.DTOs;

namespace CommunityCommuting_RideSeeker.BAL.Service.Interface
{
    public interface IRideSeekerDTO
    {
        void RegisterRideSeeker(RideSeekerDTO rideSeekerDTO);
        void UnregisterRideSeeker(string rsId);
    }
}
