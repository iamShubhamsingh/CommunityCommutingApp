﻿using CommunityCommuting_RideSeeker.BAL.DTOs;

namespace CommunityCommuting_RideSeeker.BAL.Service.Interface
{
    public interface IBookingDTO
    {
        void BookRide(/*string rsId, */BookingDTO bookingDTO);
        void CancelRide(int bookingId);
    }
}
