﻿using System;
using System.Collections.Generic;

namespace CommunityCommuting_RideSeeker.Models
{
    public partial class Booking
    {
        public int BookingId { get; set; }
        public string RsId { get; set; } = null!;
        public string? Status { get; set; }
        public DateTime? BookingDate { get; set; }

        public virtual RideSeeker Rs { get; set; } = null!;
    }
}
