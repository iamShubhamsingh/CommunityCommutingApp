﻿using System;
using System.Collections.Generic;

namespace CommunityCommuting_RideSeeker.Models
{
    public partial class RideSeeker
    {
        public RideSeeker()
        {
            Bookings = new HashSet<Booking>();
        }

        public string RsId { get; set; } = null!;
        public long? Adharcard { get; set; }
        public string? EmailId { get; set; }
        public long? Phone { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Address { get; set; }
        public string? Status { get; set; }
        public DateTime? Birthday { get; set; }

        public virtual ICollection<Booking> Bookings { get; set; }
    }
}
